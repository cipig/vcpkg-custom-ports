#ifndef ladder_namespace_H
#define ladder_namespace_H

#define  ladder  _sodium_scalarmult_curve25519_sandy2x_ladder
#define _ladder __sodium_scalarmult_curve25519_sandy2x_ladder

#endif /* ifndef ladder_namespace_H */

