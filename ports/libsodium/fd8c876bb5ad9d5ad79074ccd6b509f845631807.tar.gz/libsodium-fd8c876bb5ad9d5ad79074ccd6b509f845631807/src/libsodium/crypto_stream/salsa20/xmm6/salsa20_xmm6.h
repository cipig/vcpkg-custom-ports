
#include <stdint.h>

#include "../stream_salsa20.h"
#include "crypto_stream_salsa20.h"
#include "salsa20_xmm6-asm_namespace.h"

extern struct crypto_stream_salsa20_implementation
    crypto_stream_salsa20_xmm6_implementation;
